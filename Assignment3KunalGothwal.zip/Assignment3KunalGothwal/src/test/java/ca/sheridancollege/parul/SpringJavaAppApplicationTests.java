package ca.sheridancollege.parul;

import org.junit.jupiter.api.Test; 
import org.springframework.boot.test.context.SpringBootTest; 
 
@SpringBootTest
class SpringJavaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
