package ca.sheridancollege.parul.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test; 
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession; 
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
 
import ca.sheridancollege.parul.beans.Mission;
import ca.sheridancollege.parul.controllers.HomeController;
import ca.sheridancollege.parul.database.DatabaseAccess;
 
@SpringBootTest
@AutoConfigureTestDatabase  
@AutoConfigureMockMvc
public class TestHomeController 
{

	@Autowired
	private DatabaseAccess da;
	
	
	@Autowired
	private MockMvc mockMvc;
	 

	    @Test
	    public void testIndexPage() throws Exception 
	    {
	     mockMvc.perform(get("/")).andExpect(status().isOk())
		 .andExpect(view().name("index")).andDo(print());
	    }

	    @Test
	    public void testCreateMission() throws Exception
	    {
	        Mission mission = new Mission();
			String agent = mission.getAgents()[0];
	        mission.setTitle("Test Mission");
	        mission.setAgent(agent);
	        mission.setGadget1("Test Gadget 1");
	        mission.setGadget2("Test Gadget 2");

			int orgsize = da.getMissions(agent).size();

			 

	        mockMvc.perform(post("/create_mission")
	                .param("title", mission.getTitle())
	                .param("agent", mission.getAgent())
	                .param("gadget1", mission.getGadget1())
	                .param("gadget2", mission.getGadget2()))
	                .andExpect(status().isFound())
	                .andExpect(redirectedUrl("/view_mission?agent="+agent));

					int newSize = da.getMissions(agent).size();

					assertEquals(orgsize+1, newSize);
	    }


	    @Test
	    public void testDeleteMission() throws Exception 
	    {
	    
	    	String agent = new Mission().getAgents()[0];
	        List<Mission> missions = da.getMissions(agent);
	        Mission mission = missions.get(0);
	        int id = mission.getId();
	        
	        int orgsize = da.getMissions(agent).size();
	        
	        mockMvc.perform(get("/delete_mission/{id}", id))
	        .andExpect(status().isFound())
	        .andExpect(redirectedUrl("/"))
	        .andDo(print());
	        
	        int newSize = da.getMissions(agent).size();
	        
	        assertEquals(orgsize-1, newSize);
	    }

	    
	    @Test
	    public void testEditMission() throws Exception 
	    {
	       
			String[] agents = new Mission().getAgents();
			List<Mission> missions = da.getMissions(agents[0]);
			Mission mission = missions.get(0);
			mission.setGadget1("Test Gadget 1");

			mockMvc.perform(post("/edit_mission").flashAttr("mission", mission))
			.andExpect(status().isFound())
			.andExpect(redirectedUrl("/view_mission?agent="+mission.getAgent()))
			.andDo(print());

			assertEquals(mission.getGadget1(), "Test Gadget 1");
	    }

	    
	}
