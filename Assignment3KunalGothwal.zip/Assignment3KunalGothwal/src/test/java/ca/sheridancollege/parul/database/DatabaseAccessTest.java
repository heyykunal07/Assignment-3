package ca.sheridancollege.parul.database;
import static org.junit.jupiter.api.Assertions.assertEquals; 

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test; 
  
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest; 

import ca.sheridancollege.parul.beans.Mission; 
   
@SpringBootTest
@AutoConfigureTestDatabase  
public class DatabaseAccessTest {


    @Autowired
    private DatabaseAccess databaseAccess; 

    @Test
    public void testGetMissions() {
       
     List<Mission> result = databaseAccess.getAllMissions();
 
        assertEquals(2, result.size()); // ONly two missions in the db
    }

    @Test
    public void testAgentMissions(){
        List<Mission> missions = new ArrayList<>();
        String agent = "Test Agent";
        
        for(Mission mission : databaseAccess.getAllMissions())
        {
            if(mission.getAgent().equals(agent))
            {
                missions.add(mission);
            }
        }

        List<Mission> result = databaseAccess.getMissions(agent);

        assertEquals(missions.size(), result.size());
    }
    @Test
    public void testAddMission() {
        
        Mission mission = new Mission();
        mission.setAgent("Test Agent");
        mission.setTitle("Test Title");
        mission.setGadget1("Test Gadget 1");
        mission.setGadget2("Test Gadget 2");
        int result = databaseAccess.addMission(mission);

        assertEquals(1, result);
    }

   
    @Test
    public void testDeleteMission()
    {
        String agent = new Mission().getAgents()[0];
        List<Mission> missions = databaseAccess.getMissions(agent);
        
        int id = missions.get(0).getId();

        int orgsize = databaseAccess.getMissions(agent).size();

        databaseAccess.deleteMission(id);

        int newSize = databaseAccess.getMissions(agent).size();

        assertEquals(orgsize-1, newSize);
    }
}
