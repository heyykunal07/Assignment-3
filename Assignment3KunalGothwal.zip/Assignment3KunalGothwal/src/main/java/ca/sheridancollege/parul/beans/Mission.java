package ca.sheridancollege.parul.beans;

import lombok.Data;

@Data
public class Mission 
{
    private int id;
    private String title;
    private String gadget1;
    private String gadget2;
    private String agent;
    private final String[] agents = {"Johnny English", "Natasha Romanova", "Austin Powers"};
	public String getAgent() {
		return agent;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGadget1() {
		return gadget1;
	}
	public void setGadget1(String gadget1) {
		this.gadget1 = gadget1;
	}
	public String getGadget2() {
		return gadget2;
	}
	public void setGadget2(String gadget2) {
		this.gadget2 = gadget2;
	}
	public String[] getAgents() {
		return agents;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	    
	
}
