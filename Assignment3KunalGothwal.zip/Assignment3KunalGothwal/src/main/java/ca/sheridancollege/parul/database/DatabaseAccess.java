package ca.sheridancollege.parul.database;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.parul.beans.Mission;

@Repository
public class DatabaseAccess 
{

	private NamedParameterJdbcTemplate jdbc;

	public DatabaseAccess(NamedParameterJdbcTemplate jdbc) 
	{
		this.jdbc = jdbc;
	}

	public List<Mission> getAllMissions()
	{
		String sql = "SELECT * FROM missions";
		BeanPropertyRowMapper<Mission> mapper = new BeanPropertyRowMapper<>(Mission.class);
		
		List<Mission> missions = jdbc.query(sql, mapper);
		
		return missions;
	}
	public List<Mission> getMissions(String agent) 
	{
		String sql = "SELECT * FROM missions WHERE agent = :agent";
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("agent", agent);
		return jdbc.query(sql, params, new BeanPropertyRowMapper<>(Mission.class));
	}

	public int addMission(Mission mission) 
	{
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = "INSERT INTO missions (agent, title, gadget1, gadget2)  VALUES (:agent, :title, :gadget1, :gadget2);";
		parameters.addValue("agent", mission.getAgent()).addValue("title", mission.getTitle())
				.addValue("gadget1", mission.getGadget1()).addValue("gadget2", mission.getGadget2());

		int returnValue = jdbc.update(query, parameters);

		return returnValue;

	}

	public int deleteMission(int id)
	{
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = "DELETE FROM missions WHERE id = :myId;";

		parameters.addValue("myId", id);

		int returnValue = jdbc.update(query, parameters);

		return returnValue;
	}

	public Mission getMission(int id)
	{
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		String query = "SELECT * FROM missions WHERE id = :id;";

		parameters.addValue("id", id);

		BeanPropertyRowMapper<Mission> mapper = new BeanPropertyRowMapper<>(Mission.class);

		List<Mission> missions = jdbc.query(query, parameters, mapper);

		if (missions.isEmpty()) {
			return null; // error condition
		} else {
			return missions.get(0);
		}
	}

	public int updateMission(Mission mission)
	{
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		String query = "UPDATE missions " + "SET title=:title, gadget1=:gadget1, gadget2=:gadget2 WHERE id=:id ";

		parameters.addValue("title", mission.getTitle()).addValue("gadget1", mission.getGadget1())
				.addValue("gadget2", mission.getGadget2()).addValue("id", mission.getId());

		int returnValue = jdbc.update(query, parameters);

		return returnValue;
	}
}
