package ca.sheridancollege.parul.controllers;

/**
 * Name- Kunal Gothwal
 * Program- Enterprise Java Development
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.parul.beans.Mission;
import ca.sheridancollege.parul.database.DatabaseAccess;

@Controller
public class HomeController 
{
	private DatabaseAccess database;

	@Autowired
	public HomeController(DatabaseAccess database) 
	{
		this.database = database;
	}

	@GetMapping("/")
	public String indexPage(HttpSession session, Model model) 
	{
		Mission mission = new Mission();
		String[] agents = mission.getAgents();

		session.setAttribute("agents", agents);
		model.addAttribute("agents", agents);
		 

		return "index";
	}

	@GetMapping("/create_mission")
	public String showCreateMissionForm(Model model, HttpSession session) 
	{
		Mission mission = new Mission();
		String[] agents = mission.getAgents();

		session.setAttribute("agents", agents);
		model.addAttribute("agents", agents);
		model.addAttribute("mission", mission);
		return "create_mission";
	}

	@PostMapping("/create_mission")
	public String createMission(@ModelAttribute Mission mission) 
	{
		System.out.println(mission);
		int returnValue = database.addMission(mission);
		System.out.println("return value is: " + returnValue);

		return "redirect:/view_mission?agent=" + mission.getAgent();
	}

	@GetMapping("/delete_mission/{id}")
	public String deleteMission(@PathVariable int id, Model model, HttpSession session) 
	{
		int returnValue = database.deleteMission(id); 
		System.out.print("\nReturn value is: \n" + returnValue);
		return "redirect:/";
	}

	@GetMapping("/view_mission")
	public String viewMissions(Model model, HttpSession session, @RequestParam("agent") String agent)
	{
		System.out.println(agent + "\n\n");
		List<Mission> missions = database.getMissions(agent);

		session.setAttribute("missions", missions);
		session.setAttribute("agent", agent);
		model.addAttribute("missions", missions);
		model.addAttribute("agent", agent);

		return "view_mission";
	}

	@GetMapping("/edit_mission/{id}")
	public String editMission(@PathVariable int id, Model model, HttpSession session) 
	{
		Mission mission = database.getMission(id);

		session.setAttribute("mission", mission);
		model.addAttribute("mission", mission);

		return "edit_mission";
	}

	@PostMapping("/edit_mission")
	public String updateMission(@ModelAttribute Mission mission) 
	{
		int returnValue = database.updateMission(mission);

		System.out.println("return value is: " + returnValue);

		return "redirect:/view_mission?agent=" + mission.getAgent();
	}
}
