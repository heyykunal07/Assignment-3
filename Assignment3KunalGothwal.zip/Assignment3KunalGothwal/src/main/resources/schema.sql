CREATE TABLE missions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    gadget1 VARCHAR(255),
    gadget2 VARCHAR(255),
    agent VARCHAR(255)
);