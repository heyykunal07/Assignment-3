/* register-validation.js */

function validatePassword() {
    var password = document.getElementById('password').value;

    // Password length between 5 and 10 characters
    if (password.length < 5 || password.length > 10) {
        alert('Password must be between 5 and 10 characters.');
        return false;
    }

    // At least two numbers
    var digitCount = password.replace(/[^0-9]/g, '').length;
    if (digitCount < 2) {
        alert('Password must contain at least two numbers.');
        return false;
    }

    // At least one uppercase letter
    if (!/[A-Z]/.test(password)) {
        alert('Password must contain at least one uppercase letter.');
        return false;
    }

    // At least one special character (#,!,$,*)
    if (!/[#!$*]/.test(password)) {
        alert('Password must contain at least one of the special characters (#,!,$,*).');
        return false;
    }

    return true;
}