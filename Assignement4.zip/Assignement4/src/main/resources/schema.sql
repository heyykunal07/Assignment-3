create table books(
id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(128) NOT NULL,
author VARCHAR(128) NOT NULL);

 create table reviews(
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 bookId BIGINT NOT NULL,
 text VARCHAR(1024) NOT NULL UNIQUE);
 
 
CREATE TABLE IF NOT EXISTS usertable (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    userName VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    saltedPassword VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

alter table reviews
  add constraint book_review_fk foreign key (bookId)
  references books(id);

insert into books (title,author)
values('The 7 Habits of Highly Effective People','Stephen R Covey');
insert into books (title,author)
values('The Martian','Andy Weir');

insert into reviews (text,bookId)
values('An older book, but still a very good read',1);
insert into reviews (text,bookId)
values('A great science fiction book',2);

