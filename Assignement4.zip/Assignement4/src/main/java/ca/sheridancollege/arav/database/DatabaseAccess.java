package ca.sheridancollege.arav.database;

import ca.sheridancollege.arav.beans.Book;
import ca.sheridancollege.arav.beans.Review;
import ca.sheridancollege.arav.beans.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DatabaseAccess {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public List<Book> getAllBooks() {
        String sql = "SELECT * FROM books";
        return jdbcTemplate.query(sql, (resultSet, rowNum) -> {
            Book book = new Book();
            book.setId(resultSet.getLong("id"));
            book.setTitle(resultSet.getString("title"));
            book.setAuthor(resultSet.getString("author"));
            return book;
        });
    }

    @SuppressWarnings("deprecation")
	public Book getBookById(Long id) {
        String sql = "SELECT * FROM books WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, (resultSet, rowNum) -> {
            Book book = new Book();
            book.setId(resultSet.getLong("id"));
            book.setTitle(resultSet.getString("title"));
            book.setAuthor(resultSet.getString("author"));
            return book;
        });
    }

    @SuppressWarnings("deprecation")
	public List<Review> getReviewsByBookId(Long bookId) {
        String sql = "SELECT * FROM reviews WHERE bookId = ?";
        return jdbcTemplate.query(sql, new Object[]{bookId}, (resultSet, rowNum) -> {
            Review review = new Review();
            review.setId(resultSet.getLong("id"));
            review.setBookId(resultSet.getLong("bookId"));
            review.setText(resultSet.getString("text"));
            return review;
        });
    }

    public boolean isValidUser(String email, String password) {
        String sql = "SELECT saltedPassword FROM usertable WHERE userName = ?";
        try {
            String hashedPassword = jdbcTemplate.queryForObject(sql, String.class, email);
            return passwordEncoder.matches(password, hashedPassword);
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
	public User getUserByName(String userName) {
        String sql = "SELECT * FROM usertable WHERE userName = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{userName}, new BeanPropertyRowMapper<>(User.class));
        } catch (EmptyResultDataAccessException e) {
            return null;  // User not found
        }
    }

    public boolean isUserRegistered(String userName) {
        String sql = "SELECT COUNT(*) FROM usertable WHERE userName = ?";
        int count = jdbcTemplate.queryForObject(sql, Integer.class, userName);
        return count > 0;
    }

    public void registerUser(User user) {
        String sql = "INSERT INTO usertable (userName, email, saltedPassword) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, user.getUserName(), user.getEmail(), user.getSaltedPassword());
    }

    public void saveReview(Review review) {
        String sql = "INSERT INTO reviews (bookId, text) VALUES (?, ?)";
        jdbcTemplate.update(sql, review.getBookId(), review.getText());
    }

    public void addBook(Book book) {
        String sql = "INSERT INTO books (title, author) VALUES (?, ?)";
        jdbcTemplate.update(sql, book.getTitle(), book.getAuthor());
    }
}


