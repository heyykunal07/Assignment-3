package ca.sheridancollege.arav.controllers;

import ca.sheridancollege.arav.beans.Book;
import ca.sheridancollege.arav.database.DatabaseAccess;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class BookController {

    @Autowired
    private final DatabaseAccess databaseAccess;

    public BookController(DatabaseAccess databaseAccess) {
        this.databaseAccess = databaseAccess;
    }

    @GetMapping("/adminView")
    public String adminView(Model model) {
        List<Book> books = databaseAccess.getAllBooks();
        System.out.println(books.size());
        model.addAttribute("books", databaseAccess.getAllBooks());
        return "index";
    }

    @GetMapping("/addBook")
    public String showAddBookPage(Model model) {
        model.addAttribute("book", new Book());
        return "admin/add-book"; 
    }

    @PostMapping("/addBook")
    public String addBook(@ModelAttribute Book book, Model model) {
        try {
           
            databaseAccess.addBook(book);
            model.addAttribute("successMessage", "Book added successfully!");
            return "redirect:/adminView"; 
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error adding the book. Please try again.");
            return "admin/add-book"; 
        }
    }
}
