package ca.sheridancollege.arav.controllers;

import ca.sheridancollege.arav.beans.Book;
import ca.sheridancollege.arav.beans.Review;
import ca.sheridancollege.arav.beans.User;
import ca.sheridancollege.arav.database.DatabaseAccess;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {

    @Autowired
    private final DatabaseAccess databaseAccess;

    private boolean isUserLoggedIn;

    public HomeController(DatabaseAccess databaseAccess) {
        this.databaseAccess = databaseAccess;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("books", databaseAccess.getAllBooks());
        return "index";
    }

    @GetMapping("/view/{bookId}")
    public String viewReviews(@PathVariable Long bookId, Model model) {
        Book book = databaseAccess.getBookById(bookId);
        model.addAttribute("book", book);
        model.addAttribute("reviews", databaseAccess.getReviewsByBookId(bookId));
        if (isUserLoggedIn) {
            model.addAttribute("loggedIn", true);
        } else {
            model.addAttribute("loggedIn", false);
        }

        return "view-book";
    }


    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam("username") String email, @RequestParam("password") String password,
                               Model model, HttpSession session) {
        if ("admin".equalsIgnoreCase(email) && "pass".equals(password)) {
            session.setAttribute("loggedIn", true);
            session.setAttribute("isAdmin", true);
            return "redirect:/adminView";
        } else if (databaseAccess.isValidUser(email, password)) {
            User user = databaseAccess.getUserByName(email);
            if (user != null) {
                session.setAttribute("loggedIn", true);
                model.addAttribute("user", user);
                isUserLoggedIn = true;
                return "redirect:/";
            }
        }
        return "redirect:/permission-denied";
    }

//    @PostMapping("/login")
//    public String processLogin(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {
//        if (databaseAccess.isValidUser(username, password)) {
//            if (username != null && username.equals("admin")) {
//                return "redirect:/adminView";
//            } else {
//                return "redirect:/";
//            }
//        } else {
//            return "redirect:/login?error";
//        }
//    }

    @GetMapping("/permission-denied")
    public String permissionDenied() {
        return "error/permission-denied";
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

  
    @PostMapping("/register")
    public String processRegistration(@RequestParam("userName") String userName,
                                      @RequestParam("email") String email,
                                      @RequestParam("password") String password) {
        if (databaseAccess.isUserRegistered(userName)) {
            return "redirect:/register?error=userName";
        }
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        User user = new User(userName, email, hashedPassword);
        databaseAccess.registerUser(user);
        return "redirect:/login";
    }

    @GetMapping("/addReview/{bookId}")
    public String showAddReviewPage(@PathVariable Long bookId, Model model) {
        Book book = databaseAccess.getBookById(bookId);
        if (isUserLoggedIn) {
            model.addAttribute("loggedIn", true);
            model.addAttribute("review", new Review());
            model.addAttribute("book", book);
            return "user/add-review";
        } else {
            return "redirect:/login";
        }
    }


    @PostMapping("/submitReview")
    public String submitReview(@ModelAttribute Review review) {
        databaseAccess.saveReview(review);
        return "redirect:/view/" + review.getBookId();
    }

 
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); 
        return "redirect:/login";
    }

}
