package ca.sheridancollege.arav;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignement4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
